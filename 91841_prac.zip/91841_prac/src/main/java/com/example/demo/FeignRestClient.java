package com.example.demo;

import com.example.demo.models.Matches;
import com.example.demo.models.Student;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "client", url = "http://10.51.10.111:2200", configuration = FeignConfig.class)
public interface FeignRestClient {

    @RequestMapping(method = RequestMethod.POST, value = "students")
    Student register_student(@RequestBody Student student);

   @RequestMapping(method = RequestMethod.POST, value = "matches")
   Matches request_match(@RequestParam("studentId") Long studentId , @RequestParam("gender") String gender);

    @RequestMapping(method = RequestMethod.DELETE, value = "matches")
    Matches reject_match(@RequestBody Matches matches);

    @RequestMapping(method = RequestMethod.PUT, value = "dates")
    Matches request_my_match(@PathVariable("Blind_Date_Id") Long Blind_Date_Id, @RequestParam("matchId") Long matchId, @RequestParam("studentId") Long studentId);


}
