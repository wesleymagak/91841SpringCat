package com.example.demo;

import com.example.demo.models.Matches;
import com.example.demo.models.Student;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TestConnection implements CommandLineRunner {

    private final FeignRestClient feignRestClient;

    public TestConnection(FeignRestClient feignRestClient) {
        this.feignRestClient = feignRestClient;
    }

    @Override
    public void run(String... args) throws Exception {

        Student newStudent = feignRestClient.register_student(new Student(91841, "Wesley"));

        Matches requestMatch = feignRestClient.request_match(1L, "MALE");

        Matches rejectMatch = feignRestClient.reject_match(new Matches((long)1,(long)1, "I am male and cannot date a male"));

        Matches requestMyMatch = feignRestClient.request_my_match(1l,1l,1l);

    }
}
