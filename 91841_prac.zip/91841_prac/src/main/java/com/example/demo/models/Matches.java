package com.example.demo.models;

public class Matches {
    private Long id;
    private int studentId;
    private int matchId;
    private String reason;

    public Matches(int studentId, int matchId, String reason) {
        this.studentId = studentId;
        this.matchId = matchId;
        this.reason = reason;
    }

    public Matches(long l, long l1, String reason) {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
